const Subscriptions = () => {
  return <div>Subscriptions page</div>;
};

export default Subscriptions;
