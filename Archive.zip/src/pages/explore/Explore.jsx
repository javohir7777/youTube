
const Explore = () => {
  return (
    <div>Explore page</div>
  )
}

export default Explore