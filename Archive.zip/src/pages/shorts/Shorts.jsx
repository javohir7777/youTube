const Shorts = () => {
  return <div>Shorts page</div>;
};

export default Shorts;
